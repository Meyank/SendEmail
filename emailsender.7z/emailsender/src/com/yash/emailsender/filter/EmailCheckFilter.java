package com.yash.emailsender.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletResponse;

import com.yash.emailsender.service.SendEmailService;
import com.yash.emailsender.serviceimpl.SendEmailServiceImpl;

/**
 * Servlet Filter implementation class EmailCheckFilter
 */
@WebFilter("/EmailCheckFilter")
public class EmailCheckFilter implements Filter {

	/**
	 * this sendEmailService will be responsible to access all the services in
	 * sendEmailServiceImpl
	 */
	private SendEmailService sendEmailService;

	/**
	 * Here emailService is injected in constructor so that it will be available
	 * whenever we need it.
	 */
	public EmailCheckFilter() {
		sendEmailService = new SendEmailServiceImpl();
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		String recipientAddress = req.getParameter("recipientAddress");

		if (sendEmailService.isEmailValid(recipientAddress)) {
			chain.doFilter(req, res);
		} else {
			HttpServletResponse httpResponse = (HttpServletResponse) res;
			httpResponse.sendRedirect("home.jsp?msg= Email address entered by you is not in correct format");
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
