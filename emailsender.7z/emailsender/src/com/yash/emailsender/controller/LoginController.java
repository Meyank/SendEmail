package com.yash.emailsender.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.emailsender.model.User;
import com.yash.emailsender.service.UserService;
import com.yash.emailsender.serviceimpl.UserServiceImpl;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static UserService userService;

	public LoginController() {
		userService = new UserServiceImpl();
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		User user = userService.authenticateUser(req.getParameter("username"), req.getParameter("password"));
		if (user != null) {

			userService.generateOtp(user.getEmail(),user);
			HttpSession session = req.getSession(true);
			session.setAttribute("loggedInUser", user);
			res.sendRedirect("otpverify.jsp");
		} else
			res.sendRedirect("login.jsp?msg=Wrong UserName/Password");
	}
}
