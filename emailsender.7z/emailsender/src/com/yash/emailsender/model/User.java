package com.yash.emailsender.model;

public class User {

	private String username;
	private String email;
	private String password;
	private String contact;
	private String lastLoggedInTime;
	private String dpLocation;
	private int generatedOTP;

	public int getGeneratedOTP() {
		return generatedOTP;
	}

	public void setGeneratedOTP(int generatedOTP) {
		this.generatedOTP = generatedOTP;
	}

	public String getDpLocation() {
		return dpLocation;
	}

	public void setDpLocation(String dpLocation) {
		this.dpLocation = dpLocation;
	}

	public String getLastLoggedInTime() {
		return lastLoggedInTime;
	}

	public void setLastLoggedInTime(String lastLoggedInTime) {
		this.lastLoggedInTime = lastLoggedInTime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {

		return "Username:" + username + " || Contact: " + contact + " || Email:" + email + "|| LastLoggedInTime:"
				+ lastLoggedInTime + "";
	}
}
