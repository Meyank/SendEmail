package com.yash.emailsender.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.emailsender.model.User;

public class UserRowMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet rs, int arg1) throws SQLException {
		User user = new User();
		user.setUsername(rs.getString("username"));
		user.setPassword(rs.getString("password"));
		user.setEmail(rs.getString("email"));
		user.setContact(rs.getString("contact"));
		user.setLastLoggedInTime(rs.getString("last_logged_in_time"));
		user.setDpLocation(rs.getString("dplocation"));
		return user;
	}

}
