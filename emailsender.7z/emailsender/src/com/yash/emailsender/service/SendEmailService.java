package com.yash.emailsender.service;

import javax.mail.Session;

/**
 * This interface will declare all the services related to send email.
 * 
 * @version - 1.1
 * @since 20 April, 2018
 * 
 * @author mayank
 */
public interface SendEmailService {

	/**
	 * This method will send an email to the recipient email address passed as
	 * an argument.
	 * 
	 * @author mayank
	 * @param recipientAddress
	 *            - the address on which the email has to send.
	 * @return true if email is sent successfully or false if email is not send
	 * @exception java.lang.AssertionError
	 *                It will throw AssertionError if the credentials are
	 *                incorrect. Also if the properties are incorrect.
	 */
	public boolean sendEmail(String recipientAddress, String subject, String textTosend);

	/**
	 * This method will be used to get the Session object. It will take the
	 * properties of the email server and it will authenticate the email account
	 * with the help of email address and password. Properties are -
	 * Host,Port,Authentication,STARTTLS
	 * 
	 * @return javax.mail.Session - It will return the Session Object if the
	 *         properties and email and password are correct. - It will return
	 *         null if the properties and email and password are incorrect.
	 * 
	 * @exception java.lang.AssertionError
	 *                It will throw AssertionError if the credentials are
	 *                incorrect. Also if the properties are incorrect.
	 * 
	 * @author mayank
	 */
	public Session getMailSession();

	/**
	 * method is used for checking valid email id format.
	 * 
	 * @param email
	 * @return boolean true for valid false for invalid
	 */
	public boolean isEmailValid(String recipientAddress);
}
