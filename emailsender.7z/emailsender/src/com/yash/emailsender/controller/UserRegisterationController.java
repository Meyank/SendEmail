package com.yash.emailsender.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.bind.v2.runtime.reflect.opt.Const;
import com.yash.emailsender.model.User;
import com.yash.emailsender.service.UserService;
import com.yash.emailsender.serviceimpl.UserServiceImpl;

@WebServlet("/UserRegisterationController")
public class UserRegisterationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static UserService userService;

	public UserRegisterationController() {
		userService = new UserServiceImpl();

	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User user = new User();
		user.setUsername(request.getParameter("username"));
		user.setEmail(request.getParameter("email"));
		user.setContact(request.getParameter("contact"));
		user.setPassword(request.getParameter("password"));
		if (userService.registerUSer(user)) {
			request.getRequestDispatcher(
					"/login.jsp?msg=Congratulations,you have successfully signed up.Can login here")
					.forward(request, response);
		} else
			response.sendRedirect("userRegisteration.jsp?msg= Sorry the username is already taken !");

	}

}
