package com.yash.emailsender.serviceimpl;

import java.util.List;

import com.yash.emailsender.dao.UserDAO;
import com.yash.emailsender.daoimpl.UserDAOImpl;
import com.yash.emailsender.model.User;
import com.yash.emailsender.service.EmailService;
import com.yash.emailsender.service.UserService;

public class UserServiceImpl implements UserService {

	private static int generatedOtp;
	private static EmailService emailService;
	private static UserDAO userDAO;

	public UserServiceImpl() {
		userDAO = new UserDAOImpl();
		emailService = new EmailServiceImpl();
	}

	public void resetOTP() {
		generatedOtp = 0;
		System.out.println(generatedOtp);
	}

	@Override
	public boolean registerUSer(User user) {

		return userDAO.saveUser(user);
	}

	@Override
	public User authenticateUser(String username, String password) {

		return userDAO.authenticateUser(username, password);
	}

	public void generateOtp(String recipientAddress, User user) {

		int otp = (int) (1000000 * Math.random());
		user.setGeneratedOTP(otp);
		System.out.println(otp);

		// String textTosend = " Use this code " + generatedOtp + " to login";
		// String subject = "otp@noreply";

		// emailService.sendEmail(recipientAddress, subject, textTosend);
	}

	public boolean verifyOtp(int enteredotp, User user) {

		if (enteredotp == user.getGeneratedOTP()) {
			return true;
		}
		return false;
	}

	@Override
	public List<User> getAllUsers() {

		return userDAO.getAllUsers();
	}

	@Override
	public void updateLastLoginTime(User user) {
		userDAO.updateLastLoginTime(user);

	}

	@Override
	public void updateDpLocation(User user) {
		userDAO.updateDpLocation(user);

	}
}
