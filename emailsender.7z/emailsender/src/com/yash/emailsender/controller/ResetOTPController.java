package com.yash.emailsender.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.emailsender.service.UserService;
import com.yash.emailsender.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class ResetOTPController
 */
@WebServlet("/ResetOTPController")
public class ResetOTPController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserService userService;

	public ResetOTPController() {
		userService = new UserServiceImpl();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("main hill gya ");
		userService.resetOTP();
	
	}

}
