package com.yash.emailsender.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.emailsender.dao.UserDAO;
import com.yash.emailsender.model.User;
import com.yash.emailsender.rowmapper.UserRowMapper;
import com.yash.emailsender.util.DataSourceUtil;

public class UserDAOImpl implements UserDAO {

	private JdbcTemplate jdbcTemplate;
	private String sqlQuery;

	public UserDAOImpl() {
		jdbcTemplate = new JdbcTemplate(DataSourceUtil.getDataSource());
	}

	@Override
	public boolean saveUser(User user) {

		sqlQuery = "insert into users (username,password,contact,email) values(?,?,?,?)";
		Object[] params = new Object[] { user.getUsername(), user.getPassword(), user.getContact(), user.getEmail() };

		try {
			jdbcTemplate.update(sqlQuery, params);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	@Override
	public User authenticateUser(String username, String password) {
		sqlQuery = "select * from users where username = ? and password = ?";
		Object[] params = new Object[] { username, password };
		User user = null;
		try {
			user = jdbcTemplate.queryForObject(sqlQuery, params, new UserRowMapper());
			return user;
		} catch (DataAccessException e) {
			System.out.println("wrong username/password");
		}
		return null;
	}

	@Override
	public List<User> getAllUsers() {
		sqlQuery = "select * from users ";
		List<User> listOfUsers = new ArrayList<>();
		listOfUsers = jdbcTemplate.query(sqlQuery, new UserRowMapper());
		return listOfUsers;
	}

	@Override
	public void updateLastLoginTime(User user) {
		sqlQuery = "update users set last_logged_in_time = ? where username=?";
		Object[] params = new Object[] { user.getLastLoggedInTime(), user.getUsername() };
		jdbcTemplate.update(sqlQuery, params);

	}

	@Override
	public void updateDpLocation(User user) {
		sqlQuery = "update users set dplocation = ? where username=?";
		Object[] params = new Object[] { user.getDpLocation(), user.getUsername() };
		jdbcTemplate.update(sqlQuery, params);

	}
}
