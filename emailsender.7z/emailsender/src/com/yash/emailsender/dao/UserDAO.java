package com.yash.emailsender.dao;

import java.util.List;

import com.yash.emailsender.model.User;

public interface UserDAO {

	public boolean saveUser(User user);

	public User authenticateUser(String username, String password);

	public List<User> getAllUsers();

	public void updateLastLoginTime(User user);

	public void updateDpLocation(User user);
}
