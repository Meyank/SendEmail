function checkInputs() {

	var subject = document.getElementById("subject");
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	var recipientAddress = document.getElementById("recipientAddress");

	if (reg.test(recipientAddress.value) == false) {
		alert('Invalid Email Address');
		return false;
	}

	if (subject.value == "") {

		document.getElementById("error").innerHTML = "Subject can't be empty";
		subject.focus();

		return false;
	}

	return true;

}

function showPassword() {
	if (event.target.innerHTML == "visibility") {
		document.getElementById("password").type = "text";
		event.target.innerHTML = "visibility_off"
	} else if (event.target.innerHTML == "visibility_off") {
		document.getElementById("password").type = "password";
		event.target.innerHTML = "visibility"

	}
}
