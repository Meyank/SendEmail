package com.yash.emailsender.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.emailsender.service.EmailService;
import com.yash.emailsender.serviceimpl.EmailServiceImpl;

@WebServlet("/SendEmailController")
public class EmailController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * this sendEmailService will be responsible to access all the services in
	 * sendEmailServiceImpl
	 */
	private EmailService sendEmailService;

	/**
	 * Here emailService is injected in constructor so that it will be available
	 * whenever we need it.
	 */
	public EmailController() {
		sendEmailService = new EmailServiceImpl();
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		String recipientAddress = req.getParameter("recipientAddress");
		String subject = req.getParameter("subject");
		String textToSend = req.getParameter("textToSend");
		if (sendEmailService.sendEmail(recipientAddress, subject, textToSend)) {
			res.sendRedirect("home.jsp?msg= You're mail has been sent.");
		} else {
			res.sendRedirect("home.jsp?msg= Error in smtp properties.");
		}
	}

}
