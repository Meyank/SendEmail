package com.yash.emailsender.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.emailsender.model.User;
import com.yash.emailsender.service.UserService;
import com.yash.emailsender.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class ListAllUsersController
 */
@WebServlet("/ListAllUsersController")
public class ListAllUsersController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserService userService;

	public ListAllUsersController() {
		userService = new UserServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<User> listOfUsers = userService.getAllUsers();
		request.setAttribute("listOfUsers", listOfUsers);
		request.getRequestDispatcher("listallusers.jsp").forward(request, response);

	}

}
