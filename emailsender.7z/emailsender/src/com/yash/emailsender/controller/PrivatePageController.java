package com.yash.emailsender.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.emailsender.model.User;
import com.yash.emailsender.service.UserService;
import com.yash.emailsender.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class PrivatePageController
 */
@WebServlet("/PrivatePageController")
public class PrivatePageController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static UserService userService;

	public PrivatePageController() {

		userService = new UserServiceImpl();
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		String lastLoggedInTime = formatter.format(date);
		User user = (User) request.getSession().getAttribute("loggedInUser");
		user.setLastLoggedInTime(lastLoggedInTime);
		userService.updateLastLoginTime(user);
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Cache-Control", "no-store");
		response.setDateHeader("Expires", 0);
		response.setHeader("Pragma", "no-cache");
		request.getRequestDispatcher("/WEB-INF/home.jsp").forward(request, response);
	}

}
