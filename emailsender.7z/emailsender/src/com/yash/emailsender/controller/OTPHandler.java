package com.yash.emailsender.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.emailsender.model.User;
import com.yash.emailsender.service.UserService;
import com.yash.emailsender.serviceimpl.UserServiceImpl;

@WebServlet("/OTPHandler")
public class OTPHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static UserService userService;

	public OTPHandler() {
		userService = new UserServiceImpl();
	}

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String enteredotp = req.getParameter("enteredotp");
		HttpSession session = req.getSession(false);
		User loggedInUser = (User) session.getAttribute("loggedInUser");
		String sendOTPAgain = req.getParameter("sendOTPAgain");

		if (sendOTPAgain != null && sendOTPAgain.equalsIgnoreCase("sendOTPAgain")) {

			userService.generateOtp(loggedInUser.getEmail(), loggedInUser);
			res.sendRedirect("otpverify.jsp");
		} else if (enteredotp != null && enteredotp != ""
				&& userService.verifyOtp(Integer.parseInt(enteredotp), loggedInUser)) {
			req.getRequestDispatcher("PrivatePageController").forward(req, res);

		} else {
			session.invalidate();
			res.sendRedirect("login.jsp?msg=Otp entered was Invalid");
		}

	}
}
