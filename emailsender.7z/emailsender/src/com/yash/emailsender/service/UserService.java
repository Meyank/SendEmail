package com.yash.emailsender.service;

import java.util.List;

import com.yash.emailsender.model.User;

public interface UserService {
	public boolean registerUSer(User user);

	public User authenticateUser(String username, String password);

	public void generateOtp(String email, User user);

	public boolean verifyOtp(int otp,User user);

	public List<User> getAllUsers();

	public void resetOTP();

	public void updateLastLoginTime(User user);

	public void updateDpLocation(User user);
}
